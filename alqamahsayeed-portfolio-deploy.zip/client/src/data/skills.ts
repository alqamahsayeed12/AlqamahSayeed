export const skills = [
  "Machine Learning & Deep Learning",
  "Air Quality Modeling",
  "Satellite Data Analysis",
  "Python & R Programming",
  "TensorFlow & Keras",
  "Climate Modeling",
  "Scikit-Learn",
  "Numerical Weather Models",
  "Atmospheric Chemistry",
  "Data Visualization",
  "Research Project Management",
  "Technical Writing"
];

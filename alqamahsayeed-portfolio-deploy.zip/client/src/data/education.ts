export const education = [
  {
    degree: "Ph.D. in Atmospheric Sciences",
    institution: "University of Houston",
    location: "Houston, TX",
    period: "Jan 2018 – Aug 2021"
  },
  {
    degree: "M.Tech in Atmospheric Science and Oceanic Sciences",
    institution: "Indian Institute of Technology",
    location: "Delhi, India",
    period: "Aug 2012 – May 2014"
  },
  {
    degree: "B.Tech in Mechanical Engineering",
    institution: "Ideal Institute of Technology",
    location: "Ghaziabad, India",
    period: "Aug 2007 – June 2011"
  }
];

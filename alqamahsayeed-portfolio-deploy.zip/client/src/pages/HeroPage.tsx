import Layout from "@/components/layout/Layout";
import Hero from "@/components/sections/Hero";

export default function HeroPage() {
  return (
    <Layout>
      <Hero />
    </Layout>
  );
}
# Alqamah Sayeed Portfolio - Deployment Package

This package contains all the files needed to build and deploy your portfolio website to GitHub Pages.

## Quick Start

1. Extract this archive to a local directory
2. Open a terminal in that directory
3. Run the following commands:

```bash
npm install
npm run prepare
npm run deploy
```

For detailed instructions, please read the DEPLOYMENT_GUIDE.md file.
